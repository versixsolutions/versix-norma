// Stub para InstallPrompt
export function InstallPrompt() {
  return null;
}
