// Stub para PushPermissionBanner
export function PushPermissionBanner() {
  return null;
}
