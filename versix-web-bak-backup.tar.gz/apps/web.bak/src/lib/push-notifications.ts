// Stub para push-notifications
export function requestNotificationPermission() {}
export function saveTokenToServer() {}
