// Stub de supabase para evitar erro de importação
// Substitua pelo conteúdo real conforme necessário

export const supabase = {};
