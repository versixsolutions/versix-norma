// Stub para pwa
export function registerServiceWorker() {}
export function useOnlineStatus() {
  return true;
}
