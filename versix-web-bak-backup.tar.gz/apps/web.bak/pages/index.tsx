export default function Home() {
  return <div>Versix Norma - Placeholder</div>;
}
